package com.demo.courseApp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.courseApp.dao.CourseRepository;
import com.demo.courseApp.model.Course;



@Service
public class CourseService {
	@Autowired
	CourseRepository repository;
	public Course create(Course course){
		 return repository.save(course);
	}
	public List<Course> read() {
		return repository.findAll();
	}
	public Course read(Long id) {
		return repository.findById(id).get();
	}
	
	public Course update(Course course) {
		return repository.save(course);
	}
	public void delete(Long id) {
		repository.deleteById(id);
	}
}
