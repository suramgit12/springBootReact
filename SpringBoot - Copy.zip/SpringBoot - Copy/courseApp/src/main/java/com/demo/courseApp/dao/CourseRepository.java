package com.demo.courseApp.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.courseApp.model.Course;

public interface CourseRepository extends JpaRepository<Course,Long> {

}
