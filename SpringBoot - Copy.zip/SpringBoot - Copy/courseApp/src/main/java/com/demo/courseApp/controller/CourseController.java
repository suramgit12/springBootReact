package com.demo.courseApp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.demo.courseApp.model.Course;
import com.demo.courseApp.service.CourseService;


@CrossOrigin(origins = "http://localhost:7979")
@RestController
public class CourseController {
	@Autowired
	CourseService service;
	
	@PostMapping("/course")
	public Course addCourse(@RequestBody Course course){
		return service.create(course);
	}
	
	@GetMapping("/course")
	public List<Course> getAllCourses(){
		return service.read();
	}
	
	@GetMapping("/course/{id}")
	public Course findCourseById(@PathVariable Long id){
		return service.read(id);
	}
	
	@PutMapping("/course/{id}")
	public Course modifyCourse(@RequestBody Course course){
		return service.update(course);
	}
	
	@DeleteMapping("/course/{id}")
	public void removeCourse(@PathVariable Long id){
		service.delete(id);
	}
}
