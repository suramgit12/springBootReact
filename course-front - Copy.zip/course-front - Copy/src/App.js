import logo from './logo.svg';
import './App.css';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom';
import ListCourseComponent from './components/ListCourseComponent';
import AddCourseComponent from './components/AddCourseComponent';
import ViewCourseComponent from './components/ViewCourseComponent';
import EditCourseComponent from './components/EditCourseComponent';



function App() {
  return (
    <div>
      <Router>
       <div className="container">
         <Switch> 
 <Route path = "/" exact component = {ListCourseComponent}></Route>
<Route path = "/add-course/:id" component = {AddCourseComponent}/> 
<Route path = "/view-course/:id" component ={ViewCourseComponent}/>
<Route path = "/edit-course/:id" component ={EditCourseComponent}/>

                    </Switch>
                </div>
            
        </Router>
    </div>

  );
}

export default App;
