import axios from 'axios';

const All_COURSES= "http://localhost:9797/api/vi/courses";

class CourseService {

    getCourses(){
        return axios.get(All_COURSES);
    }

 addCourse(course){
        return axios.post(All_COURSES,course);
    }

    getCourseById(id){
        return axios.get(All_COURSES+ '/' + id);
    }

   /* updateCourse(course){
        return axios.put(All_COURSES,course);
    }*/

    deleteCourse(id){
        return axios.delete(All_COURSES+ '/' + id);
    }


}
    
export default new CourseService();
