import React, { Component } from 'react'
import CourseService from "../services/CourseService";

class EditCourseComponent extends Component{
    constructor(props) {
        super(props)
this.state = {
            id: this.props.match.params.id,
             name: '',
           monthDuration:0,
            fee:0.0,
            course: {}
            
        }
    this.updateCourse = this.updateCourse.bind(this);

    }

    componentDidMount(){
      CourseService.getCourseById(this.state.id).then( res => {
            this.setState({course: res.data});
        });
     }

updateCourse = (event) => {
   event.preventDefault();
let upcourse={id:this.state.id, name:this.state.course.name, monthDuration: this.state.monthDuration,fee:this.state.fee};
CourseService.addCourse(upcourse).then(res=>{
                   this.props.history.push('/');

                });
  }

onChange = (e) =>
        this.setState({ [e.target.name]: e.target.value });


   

    render() {
           return (
               
             <div>
                <p style={{textAlign:"center"}}>
                <h2 className="text-center">Modify Courses</h2>
                <form>

                

                <div className="form-group">
                    <label>Course Id:</label>
                    <input type="text"  name="id" className="form-control" value={this.state.id}/>
                </div>

                <div className="form-group">
                    <label>Course Name:</label>
                    <input type="text"  name="name" className="form-control" value={this.state.course.name}/>
                </div>


                <div className="form-group">
                    <label>Course Duration:</label>
                    <input type="text"  name="monthDuration" className="form-control" value={this.state.monthDuration} onChange={this.onChange}/>
                </div>

                <div className="form-group">
                    <label>Course Fee:</label>
            <input type="text" name="fee" className="form-control" value={this.state.fee} onChange={this.onChange}/>
                </div>
            
                

                <button className="btn btn-success" onClick={this.updateCourse}>Update</button>
            </form>
</p>
    </div>
 
               
        )
    }

}

export default EditCourseComponent;