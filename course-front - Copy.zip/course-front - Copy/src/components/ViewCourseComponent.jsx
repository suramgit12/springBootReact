import React, { Component } from 'react'
import CourseService from "../services/CourseService";

class ViewCourseComponent extends Component{
    constructor(props) {
        super(props)
this.state = {
            id: this.props.match.params.id,
            course: {}
        }
    }

    componentDidMount(){
      CourseService.getCourseById(this.state.id).then( res => {
            this.setState({course: res.data});
        })
    }

   

    render() {
        return (
             <div>
         <table border="1">
          <tr>
          <th>Id:</th>
          <td>{this.state.course.id }</td>
           </tr>
         <tr>
          <th>Name:</th>
          <td>{this.state.course.name }</td>
           </tr>
          <tr>
          <th>Duration:</th>
          <td>{this.state.course.monthDuration }</td>
           </tr> 
         <tr>
          <th>Fee:</th>
          <td>{this.state.course.fee }</td>
           </tr>
        </table>
</div>
              
        )
    }

}

export default ViewCourseComponent;