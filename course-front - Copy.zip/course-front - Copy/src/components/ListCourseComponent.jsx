import React, { Component } from 'react';
import CourseService from '../services/CourseService';

class ListCourseComponent extends Component {
    constructor(props) {
        super(props)
        this.state = {
                courses: []
        }
   this.addCourse = this.addCourse.bind(this);
    this.editCourse = this.editCourse.bind(this);
        this.deleteCourse = this.deleteCourse.bind(this);
       this.viewCourse = this.viewCourse.bind(this);


      }

    componentDidMount(){
   CourseService.getCourses().then((res) => {
            this.setState({ courses: res.data});
       });
    }

addCourse(){
        this.props.history.push(`/add-course/_add`);
    }

viewCourse(id){
        this.props.history.push(`/view-course/${id}`);
    }
editCourse(id){
        this.props.history.push(`/edit-course/${id}`);
    }


deleteCourse(id){
      CourseService.deleteCourse(id).then( res => {
            this.setState({courses: this.state.courses.filter(course => course.id !== id)});
        });
      this.props.history.push('/');

    }



   render() {
    return (
       <div className="text-center">
              <div className = "row" style={{textAlign:"center"}}>
           <button onClick={this.addCourse}> Add New Course</button>

             </div>

 <div>
                 <h2 className="text-center">Course List</h2>
                 
                 <br></br>
                 <div className = "row">
         <table className = "table table-striped table-bordered">
            <thead>
               <tr>
                  <th>Id</th>
                  <th>Name</th>
                  <th>Duration</th>
                  <th>Fee</th>
                   <th>View</th>
                   <th>Edit</th>
                   <th>Delete</th>
                   </tr>
              </thead>
   <tbody>
     {
    this.state.courses.map(
                          course => 
                                        
<tr key = {course.id}>
<td> {course.id} </td>   
  <td> {course.name} </td>   
  <td> {course.monthDuration}</td>
  <td> {course.fee}</td>
  <td><button onClick={()=> this.viewCourse(course.id)} >View</button></td>
 <td><button  onClick={()=> this.editCourse(course.id)}  >Edit</button></td>
<td><button onClick={()=> this.deleteCourse(course.id)} >Delete</button></td>

</tr>                                        
   )  
}                         
  </tbody>
    </table>

                 </div>

            </div>
         </div>
         
        )
    }
}

export default ListCourseComponent