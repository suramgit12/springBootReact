import React, { Component } from 'react'
import CourseService from "../services/CourseService";

class AddCourseComponent extends Component{

    constructor(props){
        super(props);
        this.state ={
            id:0,
           name: '',
           monthDuration:0,
            fee:0.0
           
        }
        this.saveCourse = this.saveCourse.bind(this);
    }

saveCourse = (event) => {
   event.preventDefault();
let course={id:this.state.id, name:this.state.name, monthDuration: this.state.monthDuration,fee:this.state.fee};
CourseService.addCourse(course).then(res=>{
                    //this.props.history.push('/courses');
                 this.props.history.push('/');

                });
  }

onChange = (e) =>
        this.setState({ [e.target.name]: e.target.value });

    render() {
        return(
            <div>
                <h2 className="text-center">Add Course</h2>
                <form>
                <div className="form-group">
                    <label>Course Id:</label>
                    <input type="text" placeholder="Course id" name="id" className="form-control" value={this.state.id} onChange={this.onChange}/>
                </div>

                <div className="form-group">
                    <label>Course Name:</label>
                    <input type="text" placeholder="Course name" name="name" className="form-control" value={this.state.name} onChange={this.onChange}/>
                </div>

                <div className="form-group">
                    <label>Course Duration:</label>
                    <input placeholder="Duration in month" name="monthDuration" className="form-control" value={this.state.monthDuration} onChange={this.onChange}/>
                </div>

                <div className="form-group">
                    <label>Course Fee:</label>
                    <input placeholder="Course Fees" name="fee" className="form-control" value={this.state.fee} onChange={this.onChange}/>
                </div>

                

                <button className="btn btn-success" onClick={this.saveCourse}>Save</button>
            </form>
    </div>
        );
    }
}

export default AddCourseComponent;